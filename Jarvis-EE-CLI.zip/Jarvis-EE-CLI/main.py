import os
import sys
import getpass
import json
import traceback
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich import print as rprint
from core.gemini_client import GeminiClient
from core.schemas import ProjectSpec, PROMPT_1_INTENT_PARSING

console = Console()

# ==========================================
# [DEBUG 配置区]
# 当您需要进行全流程测试时，请将您的 API Key 粘贴在这里（仅用于本地调试）：
DEBUG_API_KEY = ""
# ==========================================

class JarvisEEApp:
    def __init__(self):
        self.state = 0
        self.client = None
        self.running = True

    def run(self):
        """Main loop and State Machine"""
        try:
            while self.running:
                if self.state == 0:
                    self.state_0_init()
                elif self.state == 1:
                    self.state_1_main_menu()
                elif self.state == 2:
                    self.state_2_hardware_assistant()
                elif self.state == 3:
                    self.state_3_knowledge_expansion()
                elif self.state == 4:
                    self.state_4_self_reflection()
                elif self.state == 5:
                    self.state_5_render_output()
                else:
                    self.running = False
        except Exception as e:
            console.print(f"\n[bold red]检测到导致退出的全局严重异常: {e}[/bold red]")
            console.print(traceback.format_exc())
            Prompt.ask("程序崩溃，按 Enter 退出...")

    def state_0_init(self):
        """State 0: Initialization"""
        console.clear()
        console.print(Panel.fit("[bold cyan]Jarvis-EE-CLI 初始化...[/bold cyan]", title="State 0"))
        
        if not self.client:
            try:
                if DEBUG_API_KEY.strip():
                    console.print("[magenta]⚠️ 已启用 DEBUG_API_KEY 硬编码模式进行调试。[/magenta]")
                    api_key = DEBUG_API_KEY.strip()
                else:
                    console.print("[yellow]Hint: 输入过程中为了安全，键盘字符将不会在屏幕上显示。[/yellow]")
                    api_key = getpass.getpass("🔑 请输入您的 Google Gemini API Key (输入 'exit' 退出): ")
                    if not api_key:
                        console.print("[red]输入为空，请重新输入。[/red]")
                        return
                    if api_key.lower() == 'exit':
                        sys.exit(0)
                
                self.client = GeminiClient(api_key=api_key)
                _ = self.client.get_models()
                console.print(f"[green]✓ AI 核心启动成功. 默认模型: {self.client.current_model}[/green]")
                self.state = 1
            except Exception as e:
                console.print(f"[bold red]启动失败: {e}[/bold red]")
                console.print(traceback.format_exc())
                # State 保持在 0，等待下一次循环重新输入

    def state_1_main_menu(self):
        """State 1: Main Menu"""
        console.print("\n")
        menu = (
            "[1] 查看与切换模型\n"
            "[2] 硬件助理模式 (Hardware Assistant)\n"
            "[3] 退出 (Exit)"
        )
        console.print(Panel(menu, title="[bold green]主菜单 (Main Menu)[/bold green]", expand=False))
        
        choice = Prompt.ask("请选择操作", choices=["1", "2", "3"])
        
        if choice == "1":
            self.handle_model_switch()
        elif choice == "2":
            self.state = 2
        elif choice == "3":
            console.print("[yellow]Jarvis 正在关机... Goodbye![/yellow]")
            self.running = False

    def handle_model_switch(self):
        """Handle Option 1: Switch Model"""
        models = self.client.get_models()
        console.print("\n[bold cyan]可用模型列表:[/bold cyan]")
        for i, model in enumerate(models, 1):
            mark = "[*]" if model == self.client.current_model else "[ ]"
            console.print(f"{mark} {i}. {model}")
        
        idx_str = Prompt.ask(f"请选择模型编号 (1-{len(models)})，或按 Enter 返回主菜单", default="")
        if idx_str.isdigit():
            idx = int(idx_str)
            if 1 <= idx <= len(models):
                selected = models[idx-1]
                self.client.set_model(selected)
                console.print(f"[green]模型已切换至: {selected}[/green]")
            else:
                console.print("[red]无效的编号。[/red]")

    def state_2_hardware_assistant(self):
        """State 2: Intent Parsing"""
        console.clear()
        console.print(Panel("[bold yellow]🚀 欢迎进入大模型硬件助理模式[/bold yellow]\n\n在这里，请用一段自然语言描述您的硬件需求：\n例如: '帮我设计一个廉价的 12V 转 5V 电源，大约 2A 电流，给单片机和外设供电'", title="State 2 - 项目意图收集"))
        
        user_input = Prompt.ask("\n[bold cyan]需求描述[/bold cyan] (输入 'b' 返回主菜单)")
        if user_input.lower() == 'b':
            self.state = 1
            return
            
        while True:
            console.print("[cyan]正在进行意图解析，提取关键参数...[/cyan]")
            prompt = PROMPT_1_INTENT_PARSING.format(user_input=user_input)
            
            try:
                if DEBUG_API_KEY.strip():
                    console.print("[magenta]⚠️ 正在使用默认模型发请求...[/magenta]")
                    self.client.set_model("gemini-2.0-flash")

                # 使用针对 JSON 输出优化的生成方法
                response_json_str = self.client.generate_json(prompt)
                
                # 清理可能的 markdown 代码块标记 (Gemini 有时仍会返回含 ```json 的内容)
                clean_json = response_json_str.strip()
                if clean_json.startswith("```json"):
                    clean_json = clean_json[7:]
                if clean_json.startswith("```"):
                    clean_json = clean_json[3:]
                if clean_json.endswith("```"):
                    clean_json = clean_json[:-3]
                    
                parsed_data = json.loads(clean_json.strip())
                spec = ProjectSpec(**parsed_data)
                
                # 存放到工作目录
                spec_path = "temp_spec.json"
                spec.save_to_file(spec_path)
                
                console.print(f"[green]✓ 成功提取项目意图并保存至 {spec_path}[/green]")
                console.print("\n[bold magenta]当前提取的参数:[/bold magenta]")
                rprint(parsed_data)
                
                if spec.assumptions_and_questions and spec.assumptions_and_questions != "Not Specified":
                    console.print(Panel(f"[yellow]{spec.assumptions_and_questions}[/yellow]", title="[bold cyan]💡 架构师的推论与确疑[/bold cyan]"))
                
                # 询问用户是否确认进入下一阶段
                console.print("\n模型理解是否准确？继续进入深度拓扑推理阶段 (State 3)?")
                confirm = Prompt.ask("([y] 确认无误继续 / [b] 取消返回 / [接续输入文字] 回答以上问题以修正参数)", default="y")
                
                if confirm.lower() == 'y':
                    self.state = 3
                    break
                elif confirm.lower() == 'b':
                    console.print("[yellow]已取消。返回主菜单。[/yellow]")
                    self.state = 1
                    break
                else:
                    # 将用户的额外回答追加到上下文中，进入下一轮迭代重新生成
                    user_input += f"\n\n【用户补充修正】: {confirm}"
                    console.print("[cyan]收到补充信息！正在要求架构师重新推演...[/cyan]\n")
                    continue
                    
            except Exception as e:
                console.print(f"[bold red]解析意图失败 (闪退调试信息): {e}[/bold red]")
                console.print(traceback.format_exc())
                console.print("\n[yellow]原始返回内容:[/yellow]\n", response_json_str if 'response_json_str' in locals() else "未获取到返回结果")
                Prompt.ask("\n发生了内部异常，按 Enter 重置回主菜单")
                self.state = 1
                break

    def state_3_knowledge_expansion(self):
        """State 3: 知识扩展层 - Knowledge Expansion"""
        from core.schemas import PROMPT_2_HARDWARE_ARCHITECT
        console.clear()
        console.print(Panel("[bold yellow]🚀 正在进入深度拓扑推演 (State 3)...[/bold yellow]"))
        
        # Load temp_spec
        try:
            with open("temp_spec.json", 'r', encoding='utf-8') as f:
                spec_content = f.read()
        except FileNotFoundError:
            console.print("[bold red]未找到项目需求数据，请先在 State 2 中完成意图收集。[/bold red]")
            Prompt.ask("按 Enter 返回的主菜单")
            self.state = 1
            return
            
        console.print("[cyan]正在调用硬件架构师 AI 进行深度推演并查阅资料，这可能需要几十秒...[/cyan]")
        prompt = PROMPT_2_HARDWARE_ARCHITECT.format(spec_json=spec_content)
        
        # 接收来自 State 4 Reviewer 的打回修改意见附加
        if hasattr(self, "review_feedback") and self.review_feedback:
            console.print("[magenta]⚠️ 正在向架构师附加前一轮 Reviewer 的整改意见...[/magenta]")
            prompt += f"\n\n【来自 DRC 专家的严厉整改要求】：\n{self.review_feedback}\n你需要修正你上一版设计中的错误！"
            # 使用完毕后清空，避免无限循环污染
            self.review_feedback = ""
        
        try:
            if DEBUG_API_KEY.strip():
                self.client.set_model("gemini-2.0-flash")

            # Phase 3: 普通长文本推演 (输出 Markdown 格式)
            self.final_markdown_report = self.client.generate_content(prompt)
            console.print("[green]架构师推演完成！准备进行自动审查...[/green]")
            self.state = 4
        except Exception as e:
            console.print(f"[bold red]AI 推演异常: {e}[/bold red]")
            Prompt.ask("按 Enter 返回的主菜单")
            self.state = 1

    def state_4_self_reflection(self):
        """State 4: 自反馈与 DRC 层"""
        from core.schemas import PROMPT_3_REVIEWER
        console.print("\n[yellow]开始执行深度 DRC 找茬审查 (AI Reviewer)...[/yellow]")
        report = getattr(self, "final_markdown_report", "")
        
        if not report:
            console.print("[bold red]没有找到完整的架构推演报告，退回主菜单。[/bold red]")
            self.state = 1
            return
            
        prompt = PROMPT_3_REVIEWER.format(draft_report=report)
        
        try:
            if DEBUG_API_KEY.strip():
                console.print("[magenta]⚠️ [Reviewer] 正在使用默认模型发请求...[/magenta]")
                self.client.set_model("gemini-2.0-flash")

            # 使用大模型作为 Reviewer
            response_json_str = self.client.generate_json(prompt)
            clean_json = response_json_str.strip()
            if clean_json.startswith("```json"):
                clean_json = clean_json[7:]
            if clean_json.startswith("```"):
                clean_json = clean_json[3:]
            if clean_json.endswith("```"):
                clean_json = clean_json[:-3]
                
            review_result = json.loads(clean_json.strip())
            
            is_passed = review_result.get("is_passed", False)
            flaws = review_result.get("critical_flaws", [])
            feedback = review_result.get("feedback_to_architect", "")
            
            if is_passed:
                console.print("[bold green]🌟 DRC 审查通过！当前硬件方案具备较高的工程合理性。[/bold green]")
                self.state = 5
            else:
                console.print("\n[bold red]❌ DRC 审查未通过！Reviewer 发现了致命错误或缺失：[/bold red]")
                for flaw in flaws:
                    console.print(f"[red] - {flaw}[/red]")
                
                console.print(Panel(f"[yellow]{feedback}[/yellow]", title="[bold cyan]给架构师的打回修改意见[/bold cyan]"))
                
                retry = Prompt.ask("\n是否同意 Reviewer 的意见并打回架构师重构？[Y/n]", default="y")
                if retry.lower() == 'y':
                    # 将 review_feedback 附加到上下文中
                    self.review_feedback = feedback
                    self.state = 3
                else:
                    console.print("[yellow]您强制略过了审查修复意见。即将直接渲染有瑕疵的报告...[/yellow]")
                    self.state = 5

        except Exception as e:
            console.print(f"[bold red]DRC 审查模块崩溃: {e}[/bold red]")
            console.print(traceback.format_exc())
            # 如果审查机器本身挂了，询问用户是否强行查阅
            force = Prompt.ask("审查器发生内部错误，是否强行查阅未审查的初版报告？[y/N]", default="n")
            if force.lower() == 'y':
                self.state = 5
            else:
                self.state = 1
        
    def state_5_render_output(self):
        """State 5: 结构化输出 Markdown (Render)"""
        from rich.markdown import Markdown
        console.clear()
        
        if not hasattr(self, "final_markdown_report"):
            console.print("[bold red]没有可用的渲染报告。[/bold red]")
            self.state = 1
            return
            
        report_md = Markdown(self.final_markdown_report)
        console.print(Panel(report_md, title="[bold green]💡 硬件芯片助理专家级报告 💡[/bold green]", expand=False))
        
        with open("expert_report.md", "w", encoding="utf-8") as f:
            f.write(self.final_markdown_report)
            
        console.print("\n[green]报告已自动保存为 expert_report.md[/green]")
        Prompt.ask("\n流程结束。按 Enter 返回主菜单")
        self.state = 1

if __name__ == "__main__":
    app = JarvisEEApp()
    app.run()
