import os
from typing import Optional, Dict, Any
from google import genai
try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

class GeminiClient:
    def __init__(self, api_key: str, base_url: str = "", model_name: str = ""):
        """Initialize the Gemini client (Google API or OpenAI compatible)."""
        self.api_key = api_key
        self.base_url = base_url.strip()
        
        if not self.api_key:
            raise ValueError("API Key 不能为空")
            
        self.current_model = model_name.strip() if model_name.strip() else "gemini-2.0-flash"
        
        self.available_models = [
            "gemini-2.0-flash",
            "gemini-2.5-flash",
            "gemini-2.5-pro",
            "gemini-2.0-pro-exp-02-05",
            "gemini-2.0-flash-thinking-exp-01-21"
        ]
        
        if self.current_model not in self.available_models:
            self.available_models.append(self.current_model)

        self.use_openai = bool(self.base_url)
        
        if self.use_openai:
            if not OpenAI:
                raise ImportError("检测到您填入了 Base URL，这需要使用 OpenAI 通用协议，请先运行 'pip install openai'")
            self.client = OpenAI(api_key=self.api_key, base_url=self.base_url)
        else:
            self.client = genai.Client(api_key=self.api_key)

    def set_model(self, model_name: str) -> bool:
        """Switch current model."""
        if model_name not in self.available_models:
            self.available_models.append(model_name)
        self.current_model = model_name
        return True

    def get_models(self) -> list[str]:
        return self.available_models

    def generate_content(self, prompt: str, system_instruct: Optional[str] = None) -> str:
        """Generate plain text content."""
        if self.use_openai:
            messages = []
            if system_instruct:
                messages.append({"role": "system", "content": system_instruct})
            messages.append({"role": "user", "content": prompt})
            response = self.client.chat.completions.create(
                model=self.current_model,
                messages=messages,
                temperature=0.2
            )
            return response.choices[0].message.content
        else:
            config = genai.types.GenerateContentConfig(
                system_instruction=system_instruct,
                temperature=0.2
            )
            response = self.client.models.generate_content(
                model=self.current_model,
                contents=prompt,
                config=config
            )
            return response.text

    def generate_json(self, prompt: str, system_instruct: Optional[str] = None, response_schema: Any = None) -> str:
        """Generate JSON structured response enforcing a Pydantic Schema."""
        import json
        
        if self.use_openai:
            messages = []
            final_sys_instr = system_instruct or ""
            if response_schema:
                # 兼容第三方中转的最稳妥方案：除了声明 json_object，还在系统级强行把 Pydantic JSON Schema 写死在上下文里
                schema_str = json.dumps(response_schema.model_json_schema(), ensure_ascii=False)
                final_sys_instr += f"\n\n你必须按照并只输出符合以下 JSON Schema 定义的纯净 JSON 数据：\n{schema_str}"
                
            if final_sys_instr:
                messages.append({"role": "system", "content": final_sys_instr})
            messages.append({"role": "user", "content": prompt})
            try:
                # 尝试标准 json_object 模式
                response = self.client.chat.completions.create(
                    model=self.current_model,
                    messages=messages,
                    temperature=0.1,
                    response_format={"type": "json_object"}
                )
            except Exception as e:
                # 兼容某些连 json_object 都不认的中立转接器
                response = self.client.chat.completions.create(
                    model=self.current_model,
                    messages=messages,
                    temperature=0.1
                )
            return response.choices[0].message.content
        else:
            # Google GenAI 官方底层支持直接将 Pydantic 传入强力控制引擎
            kwargs = {
                "response_mime_type": "application/json",
                "temperature": 0.1
            }
            if system_instruct:
                kwargs["system_instruction"] = system_instruct
            if response_schema:
                kwargs["response_schema"] = response_schema
                
            config = genai.types.GenerateContentConfig(**kwargs)
            
            response = self.client.models.generate_content(
                model=self.current_model,
                contents=prompt,
                config=config
            )
            return response.text

    def generate_image(self, prompt: str, save_path: str) -> bool:
        """Generate an image using Imagen (Google API) or DALL-E 3 (OpenAI compatible API) and save to disk."""
        if self.use_openai:
            import urllib.request
            try:
                response = self.client.images.generate(
                    model="dall-e-3",
                    prompt=prompt,
                    n=1,
                    size="1024x1024"
                )
                image_url = response.data[0].url
                
                req = urllib.request.Request(image_url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req) as u_response:
                    img_data = u_response.read()
                
                with open(save_path, 'wb') as f:
                    f.write(img_data)
                return True
            except Exception as e:
                print(f"\n❌ Image generation failed via OpenAI API: {e}")
                return False
        else:
            try:
                result = self.client.models.generate_images(
                    model='imagen-3.0-generate-002',
                    prompt=prompt,
                    config=genai.types.GenerateImagesConfig(
                        number_of_images=1,
                        output_mime_type="image/jpeg",
                        aspect_ratio="1:1"
                    )
                )
                if result.generated_images:
                    for generated_image in result.generated_images:
                        with open(save_path, "wb") as f:
                            f.write(generated_image.image.image_bytes)
                        return True
                return False
            except Exception as e:
                print(f"\n❌ Image generation failed via Google GenAI API: {e}")
                return False
