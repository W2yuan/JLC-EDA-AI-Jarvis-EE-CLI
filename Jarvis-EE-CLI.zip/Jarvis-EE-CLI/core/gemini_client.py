import os
from google import genai
from typing import Optional, Dict, Any

class GeminiClient:
    def __init__(self, api_key: str):
        """Initialize the Gemini client."""
        self.api_key = api_key
        if not self.api_key:
            raise ValueError("API Key 不能为空")
        
        self.client = genai.Client(api_key=self.api_key)
        # Default fallback model
        self.current_model = "gemini-2.0-flash"
        self.available_models = [
            "gemini-2.0-flash",
            "gemini-2.5-flash",
            "gemini-2.5-pro",
            "gemini-2.0-pro-exp-02-05",
            "gemini-2.0-flash-thinking-exp-01-21"
        ]

    def set_model(self, model_name: str) -> bool:
        """Switch current model."""
        if model_name in self.available_models:
            self.current_model = model_name
            return True
        return False

    def get_models(self) -> list[str]:
        return self.available_models

    def generate_content(self, prompt: str, system_instruct: Optional[str] = None) -> str:
        """Generate plain text content."""
        config = genai.types.GenerateContentConfig(
            system_instruction=system_instruct,
            temperature=0.2
        )
        response = self.client.models.generate_content(
            model=self.current_model,
            contents=prompt,
            config=config
        )
        return response.text

    def generate_json(self, prompt: str, system_instruct: Optional[str] = None) -> str:
        """Generate JSON structured response."""
        config = genai.types.GenerateContentConfig(
            system_instruction=system_instruct,
            response_mime_type="application/json",
            temperature=0.1
        )
        response = self.client.models.generate_content(
            model=self.current_model,
            contents=prompt,
            config=config
        )
        return response.text
