from pydantic import BaseModel, Field
import json
from typing import Optional, List

class ProjectSpec(BaseModel):
    # 意图抽取字段
    input_voltage: str = Field(..., description="输入的电压要求，如 '12V', '220V AC', '推测为两节锂电7.4V'")
    output_voltage: str = Field(..., description="输出的电压要求，如 '5V', '3.3V'")
    current_estimate: str = Field(..., description="输出的预估电流，如 '1A', '大电流'")
    target_cost: str = Field(..., description="项目的成本敏感度，如 '廉价', '无所谓'")
    application_scenario: str = Field(..., description="应用场景和目标设备，如 'STM32主控平衡车'")
    original_intent: str = Field(..., description="从用户对话中提炼的高度概括性意图")
    assumptions_and_questions: str = Field(..., description="如果没有完整信息，写下你的工程推断以及向用户提出的确认问题；如果明确则填 '无'")

    def save_to_file(self, filepath: str = "temp_spec.json"):
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(self.model_dump_json(indent=4))

    @classmethod
    def load_from_file(cls, filepath: str = "temp_spec.json") -> Optional['ProjectSpec']:
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return cls(**data)
        except Exception:
            return None

class ReviewerResult(BaseModel):
    is_passed: bool = Field(..., description="是否通过审查，没有任何逻辑错误和缺失项")
    critical_flaws: List[str] = Field(..., description="发现的致命错误、参数倒挂或缺失的必填项列表")
    feedback_to_architect: str = Field(..., description="留给架构师的详细整改要求，将作为指令下发")

PROMPT_1_INTENT_PARSING = """
你是一个资深的硬件电子工程师助理 (意图解析专家)。
你的任务是阅读用户的模糊或随意的口语化描述，并尽可能提取出关键的硬件电源或控制系统参数。

【核心指令】：
1. 赋予工程常识：如果用户提供的参数不完整（这是常态，比如用户只说“给STM32供电”），你必须运用深厚的硬件知识进行合理推测（如主控通常需要3.3V，若是带电机则可能有12V动力电）。
2. 将你的推测逻辑以及需要向用户确认的不确定因素，写在 `assumptions_and_questions` 字段中。
3. 如果完全推算不出，依然填入 "Not Specified"，但在疑问字段中追问用户。

用户以及后续补充描述：
"{user_input}"
"""

PROMPT_2_HARDWARE_ARCHITECT = """
你是一个顶级的硬件架构师和 EMC/EMI 专家。你收到了一份已被初步结构化的项目规格需求 (JSON 格式)，以及可能附带的用户补充推论。
请根据此需求为你进行深度硬件推理与芯片选型，并严格输出一份包含多个特定模块的 Markdown 报告。

你在设计时不仅要考虑基础的逻辑连通性，更必须进行系统级工程评估。

【核心指令与约束条件】：
1. 【电源方案要求】：必须明确评估最大可能的效率，并基于此给出热功耗 (Thermal) 分析。
2. 【选型推荐】：必须推荐具体、常见市售的芯片型号（如 TPS5430, MP2315 等），附带关键参数。
3. 【工程深度考量】：针对复杂或负载敏感的电路，必须特别对“系统鲁棒性”进行分析，包含但不限于：
   - 输入/输出的瞬态电压波动性（需要 TVS、防反接或大电容稳压吗？）
   - 实际板级散热性预期（需要铺铜、打过孔或散热片吗？）
   - 电磁干扰 (EMI) 与合规性（需要磁珠、RC 吸收回路或者特定的屏蔽罩吗？）
4. 【炸机预警 / 红旗】：必须单列此模块，警告该方案实际画板时最容易忽略的致命坑。

输出必须按如下 Markdown 结构严格排版，不能缺少：
### [项目总体分析与核心参数]
...
### [推荐芯片与选型组合]
...
### [系统鲁棒性与 EMC 深度设计考量]
- **电源电压波动性防护**: ...
- **系统散热设计建议**: ...
- **电磁干扰 (EMI) 合规性建议**: ...
- **其他系统级鲁棒性措施**: ...
### [BOM清单]
...
### [Mermaid/ASCII 原理图拓扑]
...
### [炸机预警/红旗]
...

当前输入的最终项目需求数据（原需求 JSON）：
{spec_json}

{history_draft_section}
"""

PROMPT_3_REVIEWER = """
你是一个极其严苛严谨的资深“设计规则审查专家 (DRC Reviewer)”与“硬件黑客”。
你的任务是对架构师提交的初版 Markdown 报告进行“找茬”和物理边界推演。

【审查重点】：
1. 逻辑冲突：选型的芯片耐压、电流是否真能满足 JSON 需求中的边界条件？
2. 缺失元素：所有的必填章节（推荐选型、热设计、瞬态防护、炸机预警、Mermaid 拓扑图等）是否完整且具备实操指导意义？
3. 常识倒挂：是否存在荒谬的选型（如用 LDO 去做 20V 压降 2A 电流的方案导致热失控）？

【被审查的架构师初版报告】：
{draft_report}
"""

PROMPT_4_SCHEMATIC_DRAW = """
你是一个资深的硬件工程师与AI绘画提示词专家。
你的任务是阅读架构师生成的硬件设计报告，提取出所有的核心元器件（如主控芯片、电源芯片、MOS管、电感、主要电容电阻等）。
然后，你需要将这些元器件组成一个具有极客或者赛博朋克黑客风格的硬件原理图、PCBA 3D 渲染图画面的【纯英文提示词】。

【输出要求】：
1. 只能输出一句纯英文的 Prompt，绝对不要包含任何中文和其他解释性文字。
2. 提示词应适合扩散模型（如 Stable Diffusion, DALL-E 3, Imagen 等）生成高质量图像。
3. 提示词应该包含核心器件的型号文字（例如 "Microchip STM32", "MP2315" 等字样可以作为画面的印字元素），以及画法氛围（如 "highly detailed, 8k, cyberpunk, neon lights, glowing traces, blueprint, schematic diagram, dark background" 等）。
4. 你的输出仅仅是一句英文，不要带任何格式或标点引用符号。

【硬件架构师初版草案报告】：
{draft_report}
"""
